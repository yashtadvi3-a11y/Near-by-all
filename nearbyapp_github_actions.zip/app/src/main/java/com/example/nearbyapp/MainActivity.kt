package com.example.nearbyapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var chatView: TextView
    private lateinit var inputField: EditText
    private lateinit var sendBtn: Button
    private val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // programmatic layout (simple)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF071018.toInt())
        }
        chatView = TextView(this).apply { setTextColor(0xFFE6EEF8.toInt()); textSize = 14f; setPadding(16,16,16,16) }
        val scroll = ScrollView(this); scroll.addView(chatView)
        inputField = EditText(this).apply { hint = "Type a message..." }
        sendBtn = Button(this).apply { text = "Send" }

        val inputLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(inputField, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Add map fragment container
        val mapFragment = SupportMapFragment.newInstance()
        supportFragmentManager.beginTransaction().add(root.id, mapFragment).commitAllowingStateLoss()

        root.addView(inputLayout)
        setContentView(root)

        // Permissions
        val pLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            // no-op
        }
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (needed.isNotEmpty()) pLauncher.launch(needed.toTypedArray())

        // map setup (once available)
        mapFragment.getMapAsync { gmap ->
            val sample = LatLng(21.1458, 79.0882) // Nagpur approx
            gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(sample, 12f))
            gmap.addMarker(MarkerOptions().position(sample).title("You (demo)"))
        }

        sendBtn.setOnClickListener {
            val text = inputField.text.toString().trim()
            if (text.isNotEmpty()) {
                val time = dateFormat.format(Date())
                chatView.append("You (${time}): ${text}\n")
                inputField.setText("")
            }
        }
    }
}
